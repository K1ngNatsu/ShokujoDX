ShokujoDX font package: Fonts of earlier versions

A font that was in the program before version 0.4. Its quality score was below the limit of the program when it left it. Use it to change a design that has it.

To add the fonts: File > My Assets > Import a package, and choose this zip file.

Each font is a Modified Version of a font under the SIL Open Font License,
Version 1.1: the letters are embroidery objects. A font whose license has a
Reserved Font Name has a new name. The license text of each font is next to it
(<name>-OFL.txt); the notes in each font file name its source.

Font (file): source font
  Great Vibes (great-vibes.embfont): GreatVibes-Regular.ttf
