ShokujoDX font package: Fonts of earlier versions

Fonts that were in the program before version 0.4. Their quality score is below the limit of the program: some letters have parts with no stitches. Use them to change a design that has them.

To add the fonts: File > My Assets > Import a package, and choose this zip file.

Each font is a Modified Version of a font under the SIL Open Font License,
Version 1.1: the letters are embroidery objects. A font whose license has a
Reserved Font Name has a new name. The license text of each font is next to it
(<name>-OFL.txt); the notes in each font file name its source.

Font (file): source font
  Fat Face Serif (fat-face-serif.embfont): AbrilFatface-Regular.ttf
  Great Vibes (great-vibes.embfont): GreatVibes-Regular.ttf
  Shrikhand (shrikhand.embfont): Shrikhand-Regular.ttf
  Slab Heavy (slab-heavy.embfont): AlfaSlabOne-Regular.ttf
