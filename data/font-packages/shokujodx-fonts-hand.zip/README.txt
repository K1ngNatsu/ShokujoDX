ShokujoDX font package: Hand fonts

Fonts that look as if written by hand.

To add the fonts: File > My Assets > Import a package, and choose this zip file.

Each font is a Modified Version of a font under the SIL Open Font License,
Version 1.1: the letters are embroidery objects. A font whose license has a
Reserved Font Name has a new name. The license text of each font is next to it
(<name>-OFL.txt); the notes in each font file name its source.

Font (file): source font
  Architects Daughter (architects-daughter.embfont): ArchitectsDaughter-Regular.ttf
  Caveat Brush (caveat-brush.embfont): CaveatBrush-Regular.ttf
  Gloria Hallelujah (gloria-hallelujah.embfont): GloriaHallelujah.ttf
  Kalam (kalam.embfont): Kalam-Bold.ttf
  Mali (mali.embfont): Mali-Bold.ttf
  Neucha (neucha.embfont): Neucha.ttf
  Shadows Into Light (shadows-into-light.embfont): ShadowsIntoLight.ttf
  Sriracha (sriracha.embfont): Sriracha-Regular.ttf
