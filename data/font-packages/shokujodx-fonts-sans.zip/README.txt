ShokujoDX font package: Sans fonts

Plain fonts with no serifs: text, names and numbers.

To add the fonts: File > My Assets > Import a package, and choose this zip file.

Each font is a Modified Version of a font under the SIL Open Font License,
Version 1.1: the letters are embroidery objects. A font whose license has a
Reserved Font Name has a new name. The license text of each font is next to it
(<name>-OFL.txt); the notes in each font file name its source.

Font (file): source font
  Alegreya Sans (alegreya-sans.embfont): AlegreyaSans-Bold.ttf
  Amaranth (amaranth.embfont): Amaranth-Bold.ttf
  Angular Sans (angular-sans.embfont): GermaniaOne-Regular.ttf
  Barlow (barlow.embfont): Barlow-Bold.ttf
  Barlow Semi Condensed (barlow-semi-condensed.embfont): BarlowSemiCondensed-Bold.ttf
  Cabin Condensed (cabin-condensed.embfont): CabinCondensed-Bold.ttf
  Classic Sans (classic-sans.embfont): HammersmithOne-Regular.ttf
  Fast Sans (fast-sans.embfont): RacingSansOne-Regular.ttf
  Fira Sans (fira-sans.embfont): FiraSans-Bold.ttf
  Fira Sans Condensed (fira-sans-condensed.embfont): FiraSansCondensed-Bold.ttf
  Francois One (francois-one.embfont): FrancoisOne-Regular.ttf
  Game Sans (game-sans.embfont): Play-Bold.ttf
  Heavy Sans (heavy-sans.embfont): Candal.ttf
  Humanist Sans (humanist-sans.embfont): PT_Sans-Web-Bold.ttf
  Kanit (kanit.embfont): Kanit-Bold.ttf
  Khand (khand.embfont): Khand-Bold.ttf
  Machine Sans (machine-sans.embfont): RussoOne-Regular.ttf
  Mitr (mitr.embfont): Mitr-SemiBold.ttf
  Prompt (prompt.embfont): Prompt-Bold.ttf
  Rubik Mono One (rubik-mono-one.embfont): RubikMonoOne-Regular.ttf
  Sansita (sansita.embfont): Sansita-Bold.ttf
  Speed Sans (speed-sans.embfont): FugazOne-Regular.ttf
  Wide Heavy (wide-heavy.embfont): DaysOne-Regular.ttf
