ShokujoDX font package: Display fonts

Heavy and decorative fonts for short texts, and stencil fonts.

To add the fonts: File > My Assets > Import a package, and choose this zip file.

Each font is a Modified Version of a font under the SIL Open Font License,
Version 1.1: the letters are embroidery objects. A font whose license has a
Reserved Font Name has a new name. The license text of each font is next to it
(<name>-OFL.txt); the notes in each font file name its source.

Font (file): source font
  Blackletter (blackletter.embfont): PirataOne-Regular.ttf
  Bouncy Brush (bouncy-brush.embfont): Kavoon-Regular.ttf
  Candy Sans (candy-sans.embfont): BubblegumSans-Regular.ttf
  Casual Bold (casual-bold.embfont): CarterOne.ttf
  Citrus Round (citrus-round.embfont): Lemon-Regular.ttf
  Comic Narrow (comic-narrow.embfont): Acme-Regular.ttf
  Compact Heavy (compact-heavy.embfont): ChangaOne-Regular.ttf
  Display Heavy (display-heavy.embfont): Coda-ExtraBold.ttf
  Funky Slab (funky-slab.embfont): RammettoOne-Regular.ttf
  Giant Round (giant-round.embfont): TitanOne-Regular.ttf
  Jazz Hand (jazz-hand.embfont): Boogaloo-Regular.ttf
  Market Hand (market-hand.embfont): ChelseaMarket-Regular.ttf
  Poster Hand (poster-hand.embfont): Ranchers-Regular.ttf
  Poster Heavy (poster-heavy.embfont): BowlbyOne-Regular.ttf
  Saira Stencil One (saira-stencil-one.embfont): SairaStencilOne-Regular.ttf
  Sketch Sans (sketch-sans.embfont): LondrinaSolid-Regular.ttf
  Stage Round (stage-round.embfont): ConcertOne-Regular.ttf
  Stencil Sans (stencil-sans.embfont): AllertaStencil-Regular.ttf
  Stencil Serif (stencil-serif.embfont): StardosStencil-Bold.ttf
