ShokujoDX font package: Script fonts

Joined and flowing fonts.

To add the fonts: File > My Assets > Import a package, and choose this zip file.

Each font is a Modified Version of a font under the SIL Open Font License,
Version 1.1: the letters are embroidery objects. A font whose license has a
Reserved Font Name has a new name. The license text of each font is next to it
(<name>-OFL.txt); the notes in each font file name its source.

Font (file): source font
  Allura (allura.embfont): Allura-Regular.ttf
  Bold Script Two (bold-script-two.embfont): LobsterTwo-Bold.ttf
  Diner Script (diner-script.embfont): OleoScript-Bold.ttf
  Galada (galada.embfont): Galada-Regular.ttf
  Loop Script (loop-script.embfont): Sofia-Regular.ttf
  Norican (norican.embfont): Norican-Regular.ttf
  Pattaya (pattaya.embfont): Pattaya-Regular.ttf
  Pen Script (pen-script.embfont): MarckScript-Regular.ttf
  Petal Script (petal-script.embfont): LilyScriptOne-Regular.ttf
  Playball (playball.embfont): Playball-Regular.ttf
  Sign Script (sign-script.embfont): MrDafoe-Regular.ttf
  Wave Script (wave-script.embfont): SeaweedScript-Regular.ttf
