ShokujoDX font package: Serif and slab fonts

Fonts with serifs.

To add the fonts: File > My Assets > Import a package, and choose this zip file.

Each font is a Modified Version of a font under the SIL Open Font License,
Version 1.1: the letters are embroidery objects. A font whose license has a
Reserved Font Name has a new name. The license text of each font is next to it
(<name>-OFL.txt); the notes in each font file name its source.

Font (file): source font
  Bookish Slab (bookish-slab.embfont): ArbutusSlab-Regular.ttf
  Humanist Serif (humanist-serif.embfont): PT_Serif-Web-Bold.ttf
  Sturdy Serif (sturdy-serif.embfont): Volkhov-Bold.ttf
  Suez One (suez-one.embfont): SuezOne-Regular.ttf
  Swash Serif (swash-serif.embfont): BerkshireSwash-Regular.ttf
  Zilla Slab (zilla-slab.embfont): ZillaSlab-Bold.ttf
