ShokujoDX font package: Japanese fonts

Fonts with the kana, the 2,136 jōyō kanji and Japanese punctuation, and Latin letters: a gothic and a rounded gothic. The letters are large files, so they are in a package.

To add the fonts: File > My Assets > Import a package, and choose this zip file.

Each font is a Modified Version of a font under the SIL Open Font License,
Version 1.1: the letters are embroidery objects. A font whose license has a
Reserved Font Name has a new name. The license text of each font is next to it
(<name>-OFL.txt); the notes in each font file name its source.

Font (file): source font
  Noto Sans JP (noto-sans-jp.embfont): NotoSansJP[wght].ttf
  Zen Maru Gothic (zen-maru-gothic.embfont): ZenMaruGothic-Bold.ttf
